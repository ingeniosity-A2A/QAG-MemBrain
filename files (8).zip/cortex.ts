// ─────────────────────────────────────────────
// Cortex Brain — Mercury 2 (diffusion LLM)
// Receives: complete CortexPacket from executive
// Constraint: context must be COMPLETE before the call
//             Mercury 2 refines in parallel passes — no mid-call steering
//             Output arrives as a block, not a token stream
// ─────────────────────────────────────────────

import { BrainResult, CortexPacket } from "../shared/types";

const MERCURY2_ENDPOINT =
  process.env.MERCURY2_ENDPOINT ?? "https://api.inceptionlabs.ai/v1/chat/completions";
const MERCURY2_API_KEY = process.env.MERCURY2_API_KEY ?? "";
const MERCURY2_MODEL = "mercury-coder-small"; // update to mercury-2 when GA

// Mercury 2 diffusion output — arrives as a single block
interface Mercury2Response {
  id: string;
  choices: Array<{
    message: { role: string; content: string };
    finish_reason: string;
  }>;
  usage: { prompt_tokens: number; completion_tokens: number };
}

// ── Prompt assembly — must be complete before sending ────────────────────────
// This is the FULL context Mercury 2 will refine over in parallel passes.
// No information added after this point. No partial packets.
function buildCortexPrompt(packet: CortexPacket): string {
  const dagContext = packet.dag_slice
    .map(
      (a, i) =>
        `[${i + 1}] type=${a.type} importance=${a.metadata.importance} ` +
        `confidence=${a.metadata.confidence}\n    content: ${a.content}`
    )
    .join("\n");

  // Long output is intentional here — Mercury 2 diffusion latency is flat
  // regardless of output length. Be thorough.
  return `You are the cortex of the AVA007 cognitive system.
The executive brain (Mellum2) escalated this atom because it could not resolve it.

ESCALATION REASON: ${packet.escalation_reason}
EXECUTIVE INTENT: ${packet.intent}

CURRENT POLICY CONTEXT:
${packet.policy_context}

ATOM REQUIRING DEEP REASONING:
  id: ${packet.atom.id}
  type: ${packet.atom.type}
  importance: ${packet.atom.metadata.importance}
  confidence score at ingestion: ${packet.atom.metadata.confidence}
  content: ${packet.atom.content}
  tags: ${packet.atom.tags.join(", ")}

ANCESTOR DAG SLICE (${packet.dag_slice.length} atoms):
${dagContext || "  none — this is a novel atom with no prior context"}

YOUR RESPONSIBILITIES:
1. Decide the correct action for this atom
2. If the atom type is novel (no DAG match), define a new routing rule
3. If a policy conflict exists, resolve it and state which policy wins and why
4. Output a policy update if routing behavior should change going forward
5. Be verbose — latency is flat on Mercury 2, thoroughness is free

Respond ONLY with valid JSON, no markdown:
{
  "action": "<specific_action_string>",
  "confidence": <float 0.0-1.0>,
  "reasoning": "<detailed explanation>",
  "policy_update": {
    "required": <boolean>,
    "change": "<description of what should change, or null>",
    "new_known_type": "<type string to add to reflex known set, or null>"
  }
}`;
}

// ── Mercury 2 API call ────────────────────────
// Returns complete block output — no streaming
async function callMercury2(prompt: string): Promise<{
  action: string;
  confidence: number;
  reasoning: string;
  policy_update: {
    required: boolean;
    change: string | null;
    new_known_type: string | null;
  };
}> {
  const resp = await fetch(MERCURY2_ENDPOINT, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${MERCURY2_API_KEY}`,
    },
    body: JSON.stringify({
      model: MERCURY2_MODEL,
      messages: [{ role: "user", content: prompt }],
      // No stream: true — Mercury 2 diffusion returns complete block
      // Output length does not increase wall-clock latency, so no max_tokens pressure
      max_tokens: 1024,
    }),
  });

  if (!resp.ok) {
    const err = await resp.text();
    throw new Error(`Mercury 2 call failed ${resp.status}: ${err}`);
  }

  const data: Mercury2Response = await resp.json();
  const raw = data.choices[0]?.message?.content;

  if (!raw) throw new Error("Mercury 2 returned empty content");

  try {
    return JSON.parse(raw);
  } catch {
    throw new Error(`Mercury 2 returned non-JSON: ${raw.slice(0, 200)}`);
  }
}

// ── Policy update writer ──────────────────────
// If cortex decides a policy change is needed, write it as a new JSONL atom
// so the learning loop picks it up. Does NOT mutate existing atoms.
async function writePolicyUpdate(
  packet: CortexPacket,
  cortexOutput: Awaited<ReturnType<typeof callMercury2>>,
  auditLogger: (record: Record<string, unknown>) => Promise<void>
): Promise<void> {
  if (!cortexOutput.policy_update.required) return;

  await auditLogger({
    type: "policy_update",
    source: "cortex",
    title: "Cortex policy update",
    content: cortexOutput.policy_update.change,
    metadata: {
      importance: "high",
      confidence: cortexOutput.confidence,
      triggered_by_atom: packet.atom.id,
      new_known_type: cortexOutput.policy_update.new_known_type,
    },
    timestamp: Date.now(),
  });
}

// ── Main cortex entry point ───────────────────
export async function runCortex(
  packet: CortexPacket,
  auditLogger: (record: Record<string, unknown>) => Promise<void>
): Promise<BrainResult> {
  const start = Date.now();

  // Validate completeness before calling — no recovery mid-generation
  if (!packet.atom || !packet.escalation_reason || !packet.policy_context) {
    throw new Error(
      "Cortex received an incomplete packet. " +
        "Executive must assemble full context before escalating. " +
        `Missing: ${[
          !packet.atom && "atom",
          !packet.escalation_reason && "escalation_reason",
          !packet.policy_context && "policy_context",
        ]
          .filter(Boolean)
          .join(", ")}`
    );
  }

  // Build the complete prompt — nothing added after this
  const prompt = buildCortexPrompt(packet);

  // Call Mercury 2 — block output, flat latency, self-correcting across passes
  const cortexOutput = await callMercury2(prompt);

  const latency_ms = Date.now() - start;

  // Write policy update to JSONL if cortex decided one is needed
  await writePolicyUpdate(packet, cortexOutput, auditLogger);

  return {
    tier: "cortex",
    atom_id: packet.atom.id,
    action: cortexOutput.action,
    output: {
      reasoning: cortexOutput.reasoning,
      policy_update_required: cortexOutput.policy_update.required,
      new_known_type: cortexOutput.policy_update.new_known_type,
      dag_slice_depth: packet.dag_slice.length,
    },
    confidence: cortexOutput.confidence,
    model_used: MERCURY2_MODEL,
    latency_ms,
    escalate: false, // cortex is the terminal tier — no further escalation
  };
}
