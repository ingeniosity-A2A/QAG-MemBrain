// ─────────────────────────────────────────────
// Escalation gate configuration
// Written by the cortex learning loop.
// Do not hardcode these values anywhere else.
// ─────────────────────────────────────────────

import { InputType } from "./types";

export interface GateConfig {
  // Gate 1: Reflex → Executive
  reflex_pass_confidence: number;        // atom must score >= this
  reflex_known_types: InputType[];       // types reflex handles without escalating
  reflex_max_importance: "low" | "medium"; // "critical" or "high" always escalates

  // Gate 2: Executive → Cortex
  executive_pass_confidence: number;     // executive drops below this → escalate
  executive_max_dag_depth: number;       // DAG slice depth executive will reason over
  cortex_force_importance: "critical";   // always escalate — not configurable

  // Updated by cortex learning loop
  last_updated: number;                  // Unix ms
  version: number;
}

export const DEFAULT_GATE_CONFIG: GateConfig = {
  reflex_pass_confidence: 0.85,
  reflex_known_types: ["nfc_tap", "a2a_post", "webhook_known"],
  reflex_max_importance: "medium",

  executive_pass_confidence: 0.60,
  executive_max_dag_depth: 5,
  cortex_force_importance: "critical",

  last_updated: Date.now(),
  version: 1,
};

// Load from Neo4j policy node if available, else use defaults
export async function loadGateConfig(neo4jDriver?: unknown): Promise<GateConfig> {
  // TODO: query Neo4j for latest (:Policy {type: 'gate_config'}) node
  // For now return defaults
  return DEFAULT_GATE_CONFIG;
}
