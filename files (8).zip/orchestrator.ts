// ─────────────────────────────────────────────
// Brain Orchestrator
// Entry point for all atoms arriving from GSAP Layer 2.
// Implements the full escalation chain:
//   Gate 1: Reflex check (rule-based, no model call)
//   Gate 2: Executive (Mellum2) — may escalate
//   Terminal: Cortex (Mercury 2) — always resolves
// ─────────────────────────────────────────────

import { MemoryAtom, BrainResult, BrainTier } from "../shared/types";
import { GateConfig, loadGateConfig } from "../shared/gate_config";
import { runExecutive } from "../executive/executive";
import { runCortex } from "../cortex/cortex";

// ── Gate 1: Reflex check (no model, pure rules) ──────────────────────────────
// Returns true if reflex can handle this atom without escalating
function reflexCanHandle(atom: MemoryAtom, config: GateConfig): boolean {
  const typeKnown = (config.reflex_known_types as string[]).includes(atom.type);
  const confidenceOk = atom.metadata.confidence >= config.reflex_pass_confidence;
  const importanceOk =
    atom.metadata.importance !== "critical" && atom.metadata.importance !== "high";
  // Check GSAP cache hit — if this atom hash was seen before, reflex replays cached path
  // TODO: implement hash lookup against local tween cache
  return typeKnown && confidenceOk && importanceOk;
}

// ── Audit logger ─────────────────────────────────────────────────────────────
// Writes every brain decision to JSONL. Called by all three tiers.
async function writeAuditRecord(
  result: BrainResult,
  atom: MemoryAtom,
  auditAppend: (record: Record<string, unknown>) => Promise<void>
): Promise<void> {
  await auditAppend({
    type: "audit",
    source: "brain",
    title: `${result.tier} decision: ${result.action}`,
    content: JSON.stringify(result.output),
    timestamp: Date.now(),
    metadata: {
      importance: "medium",
      confidence: result.confidence,
      brain_tier: result.tier,
      model_used: result.model_used,
      latency_ms: result.latency_ms,
      atom_id: atom.id,
      atom_type: atom.type,
      escalated: result.escalate,
      escalation_reason: result.escalation_reason ?? null,
    },
  });
}

// ── Reflex action dispatcher ──────────────────────────────────────────────────
// When Gate 1 passes, reflex handles the atom with a cached response path.
// No model call. Returns a BrainResult directly.
async function runReflex(atom: MemoryAtom): Promise<BrainResult> {
  const start = Date.now();

  // Map known types to their direct actions
  const actionMap: Record<string, string> = {
    nfc_tap: "trigger_a2a_handshake",
    a2a_post: "route_to_agent",
    webhook_known: "process_webhook_payload",
  };

  const action = actionMap[atom.type] ?? "log_and_passthrough";

  return {
    tier: "reflex",
    atom_id: atom.id,
    action,
    output: { cached: true, pattern_matched: atom.type },
    confidence: atom.metadata.confidence, // trusts ingestion confidence directly
    model_used: "on-device-nemotron-nano", // or "gemma" depending on device
    latency_ms: Date.now() - start,
    escalate: false,
  };
}

// ── Main orchestrator ─────────────────────────────────────────────────────────
export async function processAtom(
  atom: MemoryAtom,
  deps: {
    neo4jDriver: any;
    auditAppend: (record: Record<string, unknown>) => Promise<void>;
    currentPolicy?: string;
  }
): Promise<{
  result: BrainResult;
  tier_used: BrainTier;
  total_latency_ms: number;
}> {
  const start = Date.now();
  const config = await loadGateConfig(deps.neo4jDriver);

  let result: BrainResult;

  // ── Gate 1: Reflex ────────────────────────────────────────────────────────
  if (reflexCanHandle(atom, config)) {
    result = await runReflex(atom);
    await writeAuditRecord(result, atom, deps.auditAppend);
    return {
      result,
      tier_used: "reflex",
      total_latency_ms: Date.now() - start,
    };
  }

  // ── Gate 2: Executive (Mellum2) ───────────────────────────────────────────
  const { result: execResult, cortexPacket } = await runExecutive(
    atom,
    deps.neo4jDriver,
    config,
    deps.currentPolicy
  );

  await writeAuditRecord(execResult, atom, deps.auditAppend);

  if (!execResult.escalate) {
    return {
      result: execResult,
      tier_used: "executive",
      total_latency_ms: Date.now() - start,
    };
  }

  // ── Terminal: Cortex (Mercury 2) ──────────────────────────────────────────
  // cortexPacket is guaranteed non-null when escalate=true
  // It was assembled completely by the executive — no additions here
  if (!cortexPacket) {
    throw new Error("Executive set escalate=true but did not produce a CortexPacket");
  }

  const cortexResult = await runCortex(cortexPacket, deps.auditAppend);
  await writeAuditRecord(cortexResult, atom, deps.auditAppend);

  return {
    result: cortexResult,
    tier_used: "cortex",
    total_latency_ms: Date.now() - start,
  };
}

// ── Usage example ─────────────────────────────────────────────────────────────
/*
import neo4j from "neo4j-driver";
import { appendToJsonl } from "../memory/jsonl/io";

const driver = neo4j.driver("bolt://localhost:7687", neo4j.auth.basic("neo4j", "password"));

const atom: MemoryAtom = {
  id: "550e8400-e29b-41d4-a716-446655440000",
  type: "nfc_tap",
  source: "dock_station_3",
  title: "Asset tag handshake",
  content: "Tap from asset tag 0x7F3A",
  timestamp: Date.now(),
  tags: ["nfc", "dock"],
  metadata: { confidence: 0.98, importance: "high" },
  vertex_hash: "0xabc123",
  signature: "ed25519:...",
};

const { result, tier_used, total_latency_ms } = await processAtom(atom, {
  neo4jDriver: driver,
  auditAppend: (record) => appendToJsonl("./audit.jsonl", record),
  currentPolicy: "route NFC taps to A2A handshake unless importance=critical",
});

console.log(`Handled by ${tier_used} in ${total_latency_ms}ms: ${result.action}`);
*/
