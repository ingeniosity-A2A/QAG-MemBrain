// ─────────────────────────────────────────────
// Executive Brain — Mellum2 MoE
// Receives: atom + DAG slice from Neo4j
// Decides: handle directly OR assemble CortexPacket and escalate
// ─────────────────────────────────────────────

import {
  MemoryAtom,
  BrainResult,
  CortexPacket,
  InputType,
} from "../shared/types";
import { GateConfig, DEFAULT_GATE_CONFIG } from "../shared/gate_config";

const MELLUM2_ENDPOINT =
  process.env.MELLUM2_ENDPOINT ?? "http://localhost:11434/api/generate";
const MELLUM2_MODEL = "mellum2"; // Ollama model name or API identifier

// ── Neo4j DAG slice query ─────────────────────
// Fetches ancestor atoms up to `depth` hops in the Tashi DAG
async function fetchDagSlice(
  atom: MemoryAtom,
  depth: number,
  neo4jDriver: any
): Promise<MemoryAtom[]> {
  const session = neo4jDriver.session();
  try {
    const result = await session.run(
      `
      MATCH (root:Memory {id: $id})-[:PRECEDES*1..$depth]->(ancestor:Memory)
      RETURN ancestor
      ORDER BY ancestor.timestamp DESC
      LIMIT 20
      `,
      { id: atom.id, depth }
    );
    return result.records.map((r: any) => r.get("ancestor").properties as MemoryAtom);
  } finally {
    await session.close();
  }
}

// ── Policy conflict check ─────────────────────
// If two DAG paths disagree on what to do with this atom type → escalate
async function detectPolicyConflict(
  atom: MemoryAtom,
  dagSlice: MemoryAtom[],
  neo4jDriver: any
): Promise<boolean> {
  const session = neo4jDriver.session();
  try {
    const result = await session.run(
      `
      MATCH (m:Memory {id: $id})<-[:INFLUENCED]-(p:Policy)
      WHERE p.type = 'routing' AND p.action <> $expected_action
      RETURN count(p) AS conflicts
      `,
      { id: atom.id, expected_action: atom.type }
    );
    const conflicts = result.records[0]?.get("conflicts").toNumber() ?? 0;
    return conflicts > 0;
  } finally {
    await session.close();
  }
}

// ── Mellum2 inference call ────────────────────
// Sends atom + DAG slice as context, gets routing decision back
async function callMellum2(
  atom: MemoryAtom,
  dagSlice: MemoryAtom[],
  policy: string
): Promise<{ action: string; confidence: number; reasoning: string }> {
  const prompt = buildExecutivePrompt(atom, dagSlice, policy);

  const startMs = Date.now();
  const resp = await fetch(MELLUM2_ENDPOINT, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      model: MELLUM2_MODEL,
      prompt,
      stream: false,
      format: "json",
    }),
  });

  if (!resp.ok) throw new Error(`Mellum2 call failed: ${resp.status}`);
  const data = await resp.json();

  // Mellum2 returns JSON — parse the response field
  let parsed: { action: string; confidence: number; reasoning: string };
  try {
    parsed = JSON.parse(data.response);
  } catch {
    throw new Error(`Mellum2 returned non-JSON: ${data.response}`);
  }

  return parsed;
}

function buildExecutivePrompt(
  atom: MemoryAtom,
  dagSlice: MemoryAtom[],
  policy: string
): string {
  const dagSummary = dagSlice
    .slice(0, 5)
    .map((a) => `- [${a.type}] ${a.title} (confidence: ${a.metadata.confidence})`)
    .join("\n");

  return `You are the executive brain of the AVA007 cognitive system.
Your job: decide what action to take for this input atom, or declare you cannot and escalate.

CURRENT ROUTING POLICY:
${policy}

INCOMING ATOM:
type: ${atom.type}
importance: ${atom.metadata.importance}
confidence: ${atom.metadata.confidence}
content: ${atom.content}

RECENT DAG CONTEXT (ancestor atoms):
${dagSummary || "none"}

Respond ONLY with valid JSON, no markdown:
{
  "action": "<specific_action_string>",
  "confidence": <float 0.0-1.0>,
  "reasoning": "<one sentence>"
}

If you cannot resolve this with confidence >= 0.60, set action to "escalate_to_cortex".`;
}

// ── Gate 2 check ──────────────────────────────
function shouldEscalateToCortex(
  atom: MemoryAtom,
  mellumResult: { action: string; confidence: number },
  hasConflict: boolean,
  config: GateConfig
): { escalate: boolean; reason?: string } {
  if (atom.metadata.importance === "critical") {
    return { escalate: true, reason: "importance is critical — always escalates" };
  }
  if (hasConflict) {
    return { escalate: true, reason: "policy conflict detected in DAG" };
  }
  if (mellumResult.confidence < config.executive_pass_confidence) {
    return {
      escalate: true,
      reason: `confidence ${mellumResult.confidence} below threshold ${config.executive_pass_confidence}`,
    };
  }
  if (mellumResult.action === "escalate_to_cortex") {
    return { escalate: true, reason: "executive self-reported inability to resolve" };
  }
  return { escalate: false };
}

// ── Main executive entry point ────────────────
export async function runExecutive(
  atom: MemoryAtom,
  neo4jDriver: any,
  config: GateConfig = DEFAULT_GATE_CONFIG,
  currentPolicy: string = "default: route by type and confidence"
): Promise<{ result: BrainResult; cortexPacket?: CortexPacket }> {
  const start = Date.now();

  // 1. Pull DAG context from Neo4j
  const dagSlice = await fetchDagSlice(atom, config.executive_max_dag_depth, neo4jDriver);

  // 2. Check for policy conflicts
  const hasConflict = await detectPolicyConflict(atom, dagSlice, neo4jDriver);

  // 3. Call Mellum2
  const mellumResult = await callMellum2(atom, dagSlice, currentPolicy);

  // 4. Gate 2 decision
  const { escalate, reason } = shouldEscalateToCortex(
    atom,
    mellumResult,
    hasConflict,
    config
  );

  const latency_ms = Date.now() - start;

  const result: BrainResult = {
    tier: "executive",
    atom_id: atom.id,
    action: escalate ? "escalate_to_cortex" : mellumResult.action,
    output: { reasoning: mellumResult.reasoning, dag_depth: dagSlice.length },
    confidence: mellumResult.confidence,
    model_used: MELLUM2_MODEL,
    latency_ms,
    escalate,
    escalation_reason: reason,
  };

  // 5. If escalating, assemble the full context packet for Mercury 2
  // This must be COMPLETE before cortex is called — no partial commits
  let cortexPacket: CortexPacket | undefined;
  if (escalate) {
    cortexPacket = {
      atom,
      dag_slice: dagSlice,
      policy_context: currentPolicy,
      intent: mellumResult.reasoning,
      escalation_reason: reason ?? "unknown",
    };
  }

  return { result, cortexPacket };
}
