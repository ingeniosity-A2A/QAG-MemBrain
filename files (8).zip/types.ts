// ─────────────────────────────────────────────
// Shared types across reflex / executive / cortex
// ─────────────────────────────────────────────

export type Importance = "low" | "medium" | "high" | "critical";
export type BrainTier = "reflex" | "executive" | "cortex";
export type InputType =
  | "nfc_tap"
  | "a2a_post"
  | "webhook_known"
  | "document"
  | "user_message"
  | "agent_event"
  | "sensor"
  | "unknown";

// The JSONL atom as it arrives from Layer 0
export interface MemoryAtom {
  id: string;                  // UUID
  type: InputType;
  source: string;              // "nfc" | "a2a" | "webhook" | "user" | ...
  title: string;
  content: string;
  timestamp: number;           // Unix ms
  tags: string[];
  embedding?: number[];        // populated after ingestion
  metadata: {
    confidence: number;        // 0.0 – 1.0
    importance: Importance;
    url?: string;
    author?: string;
  };
  vertex_hash: string;         // SHA-256 from Tashi L1
  signature: string;           // Ed25519
}

// What every brain tier returns
export interface BrainResult {
  tier: BrainTier;
  atom_id: string;
  action: string;              // what was decided
  output: Record<string, unknown>;
  confidence: number;          // model's self-reported confidence
  model_used: string;
  latency_ms: number;
  escalate: boolean;           // true = caller must pass to next tier
  escalation_reason?: string;
}

// Context packet Mellum2 assembles before calling Mercury 2
export interface CortexPacket {
  atom: MemoryAtom;
  dag_slice: MemoryAtom[];     // relevant ancestor atoms from Neo4j
  policy_context: string;      // current routing policy as text
  intent: string;              // executive's stated intent for this escalation
  escalation_reason: string;
}
